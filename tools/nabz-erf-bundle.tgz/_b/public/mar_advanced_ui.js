
// ═══════════════════════════════════════════════════════════
//  NABZ — MAR Advanced UI
//  Standards: ISMP 2024, JCI IPSG.3, 5-rights verified mode
// ═══════════════════════════════════════════════════════════
(function() {
  'use strict';

  const SCALE_FA = { pain:'درد', nausea:'تهوع', anxiety:'اضطراب', dyspnea:'تنگی نفس', pruritus:'خارش', agitation:'بی‌قراری', custom:'سایر' };

  const M = {
    _api: (p, o) => NABZ._api(p, o),
    _esc: s => NABZ._esc(s),
    _tab: 'due',
    _cache: null,

    _fmtTime(iso) {
      try {
        const d = new Date(iso);
        return d.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
      } catch (_) { return '—'; }
    },

    _closeAll() { document.querySelectorAll('.bs-backdrop').forEach(el => el.remove()); },

    _openSheet(html, opts) {
      opts = opts || {};
      const sheet = document.createElement('div');
      sheet.className = 'bs-backdrop';
      sheet.onclick = e => { if (e.target === sheet && !opts.noClose) sheet.remove(); };
      const c = document.createElement('div');
      c.className = 'bs-sheet';
      c.style.maxHeight = '95vh';
      c.innerHTML = html;
      sheet.appendChild(c);
      document.body.appendChild(sheet);
      requestAnimationFrame(() => sheet.classList.add('show'));
      return { sheet, content: c };
    },

    // ═══════════════════════════════════════════════════
    //  MAIN BOARD
    // ═══════════════════════════════════════════════════
    async show(p, d) {
      const m = document.getElementById('content');
      m.innerHTML = '<div style="text-align:center;padding:40px"><span class="spinner"></span></div>';
      try {
        const [detail, overdue, handoff] = await Promise.all([
          M._api('/api/mar/detailed'),
          M._api('/api/mar/overdue'),
          M._api('/api/mar/handoff')
        ]);
        M._cache = { detail, overdue, handoff };

        const all = detail.items || [];
        const overdueList = overdue.items || [];
        const handoffCounts = handoff.counts || {};

        // Filter by current tab
        const tab = M._tab || 'due';
        let items;
        if (tab === 'due') items = all.filter(x => ['scheduled','due'].includes(x.status)).slice(0, 50);
        else if (tab === 'prn') items = all.filter(x => x._isPRN).slice(0, 50);
        else if (tab === 'high') items = all.filter(x => x._isHighAlert || x._isVeryHighAlert).slice(0, 50);
        else if (tab === 'overdue') items = overdueList;
        else if (tab === 'history') items = all.filter(x => ['given','refused','missed'].includes(x.status)).slice(0, 50);
        else items = all.slice(0, 50);

        let h = '';
        h += '<div class="sec-hd"><span>💊 MAR — مدیریت دارو</span>';
        h += '<span class="rd-mini">' + all.length + ' رکورد</span></div>';

        // Critical alerts banner
        const veryOverdue = overdueList.filter(x => x.severity === 'critical').length;
        const veryHighAlerts = all.filter(x => x._isVeryHighAlert && x.status === 'due').length;
        if (veryOverdue > 0 || veryHighAlerts > 0) {
          h += '<div style="background:var(--dng-soft);border:2px solid var(--dng);border-radius:12px;padding:12px;margin-bottom:12px">';
          h += '<div style="font-size:13px;font-weight:900;color:var(--dng)">🚨 نیاز فوری به توجه</div>';
          if (veryOverdue > 0) h += '<div style="font-size:12px;margin-top:4px">' + veryOverdue + ' دوز بسیار دیرکرد (>۲ ساعت)</div>';
          if (veryHighAlerts > 0) h += '<div style="font-size:12px;margin-top:2px">' + veryHighAlerts + ' داروی Very-High-Alert در صف</div>';
          h += '</div>';
        }

        // Stats
        h += '<div class="rd-stats" style="grid-template-columns:repeat(4,1fr);margin-bottom:12px">';
        h += '<div class="rd-stat ' + (overdueList.length > 0 ? 'dng' : 'ok') + '"><div class="v">' + overdueList.length + '</div><div class="l">دیرکرد</div></div>';
        h += '<div class="rd-stat warn"><div class="v">' + (handoffCounts.prnWithoutEffectiveness || 0) + '</div><div class="l">PRN بی‌ارزیابی</div></div>';
        h += '<div class="rd-stat info"><div class="v">' + (handoffCounts.highAlertGiven || 0) + '</div><div class="l">High-Alert ۸h</div></div>';
        h += '<div class="rd-stat"><div class="v">' + (handoffCounts.missed || 0) + '</div><div class="l">Missed ۸h</div></div>';
        h += '</div>';

        // Quick actions
        h += '<div style="display:flex;gap:6px;margin-bottom:12px">';
        h += '<button class="btn btn-sm" style="padding:8px 12px;font-size:11px" onclick="NABZ.marUI.slidingScale()">🧮 Sliding Scale</button>';
        h += '<button class="btn btn-sm" style="padding:8px 12px;font-size:11px" onclick="NABZ.marUI.handoff()">📋 تحویل شیفت</button>';
        h += '<button class="btn btn-sm" style="padding:8px 12px;font-size:11px" onclick="NABZ.marUI.highAlertAudit()">🔍 High-Alert Audit</button>';
        h += '</div>';

        // Tabs
        h += '<div class="crisis-tabs" style="margin-bottom:12px">';
        const tabs = [
          ['due', '📋 در نوبت (' + all.filter(x => ['scheduled','due'].includes(x.status)).length + ')'],
          ['overdue', '⏰ دیرکرد (' + overdueList.length + ')'],
          ['prn', '💊 PRN (' + all.filter(x => x._isPRN).length + ')'],
          ['high', '⚠️ پرخطر (' + all.filter(x => x._isHighAlert || x._isVeryHighAlert).length + ')'],
          ['history', '📚 تاریخچه']
        ];
        tabs.forEach(([key, label]) => {
          h += '<button class="crisis-tab' + (tab === key ? ' on' : '') + '" onclick="NABZ.marUI.setTab(\'' + key + '\')">' + label + '</button>';
        });
        h += '</div>';

        // Items list
        if (!items.length) {
          h += '<div class="empty" style="padding:30px">موردی در این دسته نیست</div>';
        } else {
          items.forEach(item => {
            h += M._renderItem(item, tab);
          });
        }

        m.innerHTML = h;
        NABZ.state.current = p ? p.id : 'clinical.mar';
      } catch (e) {
        m.innerHTML = '<div class="empty">خطا: ' + M._esc(e.message) + '</div>';
      }
    },

    _renderItem(x, tab) {
      let cls = '';
      if (x._isVeryOverdue || x.severity === 'critical') cls = 'hi';
      else if (x._isOverdue || x.severity === 'high') cls = 'md';
      else if (x._isHighAlert || x._isVeryHighAlert) cls = 'md';

      let h = '<div class="row ' + cls + '" style="margin-bottom:6px">';
      h += '<div class="row-hd">';
      h += '<div class="row-title">';
      if (x._isVeryHighAlert) h += '🔴 ';
      else if (x._isHighAlert) h += '⚠️ ';
      h += M._esc(x.drugName || '') + (x.dose ? ' — ' + M._esc(x.dose) : '');
      h += '</div>';
      // Status badge
      const statusMap = { scheduled:'نوبت', due:'موعد', given:'داده‌شده', missed:'missed', refused:'رد', cancelled:'لغو' };
      const statusCls = { scheduled:'info', due:'warn', given:'ok', missed:'dng', refused:'dng', cancelled:'' };
      h += '<span class="pill ' + (statusCls[x.status] || 'info') + '">' + (statusMap[x.status] || x.status) + '</span>';
      h += '</div>';

      // Meta line
      h += '<div class="row-meta">' + M._esc(x.patientName || '') + (x.wardCode ? ' · ' + M._esc(x.wardCode) : '') + '</div>';
      h += '<div class="row-meta" style="font-size:11px">';
      if (x._minutesFromScheduled != null && x._minutesFromScheduled !== 0) {
        const dir = x._minutesFromScheduled > 0 ? 'تأخیر' : 'زودتر';
        const absMin = Math.abs(x._minutesFromScheduled);
        const col = x._minutesFromScheduled > 30 ? 'var(--dng)' : x._minutesFromScheduled > 0 ? 'var(--warn)' : 'var(--ok)';
        h += '<span style="color:' + col + ';font-weight:800">' + absMin + ' دقیقه ' + dir + '</span>';
        h += ' · ';
      }
      h += 'زمان: ' + M._fmtTime(x.scheduledAt || x.administeredAt);
      if (x.route) h += ' · ' + M._esc(x.route);
      h += '</div>';

      // PRN effectiveness pending indicator
      if (x._needsEffectiveness) {
        h += '<div style="margin-top:6px;padding:6px;background:var(--warn-soft);border:1px solid var(--warn);border-radius:6px;font-size:11px;color:var(--warn);font-weight:800">📊 نیاز به ثبت اثربخشی PRN</div>';
      }
      if (x._hasEffectiveness && tab === 'history') {
        h += '<div style="margin-top:6px;padding:6px;background:var(--ok-soft);border:1px solid var(--ok);border-radius:6px;font-size:11px;color:var(--ok);font-weight:800">✅ اثربخشی ثبت شده</div>';
      }
      if (x.lateReason) {
        h += '<div class="row-meta" style="font-size:10.5px;color:var(--dng)">دلیل تأخیر: ' + M._esc(x.lateReason) + '</div>';
      }

      // Actions
      h += '<div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">';
      if (['scheduled','due'].includes(x.status)) {
        h += '<button class="btn btn-primary btn-sm" style="padding:6px 12px;font-size:11px;flex:1;min-width:120px" onclick="event.stopPropagation();NABZ.marUI.administer(\'' + x.id + '\')">💉 توزیع</button>';
      }
      if (x._needsEffectiveness) {
        h += '<button class="btn btn-sm" style="padding:6px 12px;font-size:11px;flex:1;min-width:120px;background:var(--warn-soft);color:var(--warn);border-color:var(--warn)" onclick="event.stopPropagation();NABZ.marUI.prnEffectiveness(\'' + x.id + '\')">📊 اثربخشی</button>';
      }
      if (['scheduled','due'].includes(x.status) && x._isPRN) {
        h += '<button class="btn btn-sm" style="padding:6px 12px;font-size:11px;color:var(--dng);border-color:var(--dng)" onclick="event.stopPropagation();NABZ.marUI.refuse(\'' + x.id + '\')">✗ رد</button>';
      }
      h += '</div>';

      h += '</div>';
      return h;
    },

    setTab(tab) {
      M._tab = tab;
      M.show(null, null);
    },

    // ═══════════════════════════════════════════════════
    //  ADMINISTER MODAL
    // ═══════════════════════════════════════════════════
    async administer(marId) {
      try {
        const d = await M._api('/api/mar/detailed');
        const m = (d.items || []).find(x => x.id === marId);
        if (!m) return alert('MAR یافت نشد');

        const drift = m._minutesFromScheduled || 0;
        const isLate = drift > 30;
        const isVeryLate = drift > 60;
        const needsWitness = m._isHighAlert || m._isVeryHighAlert;
        const isVeryHigh = m._isVeryHighAlert;

        let h = '<div class="bs-handle"></div>';
        h += '<div class="bs-hd"><div class="bs-title">💊 توزیع — ' + M._esc(m.drugName) + '</div>';
        h += '<button class="bs-close" onclick="this.closest(\'.bs-backdrop\').remove()">✕</button></div>';

        // Patient + drug card
        h += '<div class="card" style="background:linear-gradient(135deg,rgba(6,182,212,0.1),rgba(139,92,246,0.05));margin-bottom:12px">';
        h += '<div style="font-weight:900;font-size:14px">' + M._esc(m.patientName) + '</div>';
        h += '<div style="font-size:11.5px;color:var(--fg-2);margin-top:2px">' + M._esc(m.wardCode || '') + ' · ' + M._esc(m.route || '') + ' · ' + M._esc(m.dose || '') + '</div>';
        if (isVeryHigh) h += '<div style="margin-top:6px;padding:6px;background:var(--dng-soft);border-radius:6px;font-size:11px;color:var(--dng);font-weight:900">🔴 VERY HIGH-ALERT — نیاز به attending + شاهد</div>';
        else if (needsWitness) h += '<div style="margin-top:6px;padding:6px;background:var(--warn-soft);border-radius:6px;font-size:11px;color:var(--warn);font-weight:900">⚠️ HIGH-ALERT — نیاز به شاهد</div>';
        h += '</div>';

        // Timing
        h += '<div style="font-size:12px;margin-bottom:12px;padding:10px;background:var(--bg-2);border-radius:8px">';
        h += '<div style="display:flex;justify-content:space-between"><span>زمان برنامه:</span><b>' + M._fmtTime(m.scheduledAt) + '</b></div>';
        h += '<div style="display:flex;justify-content:space-between;margin-top:2px"><span>الان:</span><b>' + M._fmtTime(new Date().toISOString()) + '</b></div>';
        if (drift > 0) {
          const col = isVeryLate ? 'var(--dng)' : isLate ? 'var(--warn)' : 'var(--ok)';
          h += '<div style="color:' + col + ';font-weight:900;margin-top:6px">⏱ ' + drift + ' دقیقه تأخیر</div>';
        } else if (drift < -15) {
          h += '<div style="color:var(--dng);font-weight:900;margin-top:6px">⏱ ' + Math.abs(drift) + ' دقیقه زودتر از موعد</div>';
        }
        h += '</div>';

        // Barcode input (optional)
        h += '<div class="wf-field"><label>📷 بارکد بیمار (اختیاری — 5 rights verified mode)</label>';
        h += '<input type="text" id="marBarcode" placeholder="اسکن یا تایپ: PAT-XXX" style="font-family:monospace" oninput="NABZ.marUI._barcodeCheck(this)">';
        h += '<div id="marBarcodeResult" style="font-size:10px;color:var(--fg-2);margin-top:2px"></div></div>';

        // 5 Rights
        h += '<div style="font-size:11px;font-weight:900;color:var(--primary);margin:12px 0 6px;padding-bottom:4px;border-bottom:1px solid var(--border)">✅ ۵ Rights — همه باید تأیید شوند</div>';
        const rights = [
          { key: 'patient', label: 'بیمار صحیح', value: m.patientId },
          { key: 'drug', label: 'داروی صحیح', value: m.drugName },
          { key: 'dose', label: 'دوز صحیح', value: m.dose },
          { key: 'route', label: 'مسیر صحیح', value: m.route },
          { key: 'time', label: 'زمان صحیح', value: M._fmtTime(m.scheduledAt) }
        ];
        rights.forEach(r => {
          h += '<label style="display:flex;align-items:center;gap:10px;padding:8px;background:var(--bg-2);border-radius:6px;margin-bottom:4px;font-size:11.5px;cursor:pointer">';
          h += '<input type="checkbox" data-right="' + r.key + '" style="width:20px;height:20px;accent-color:var(--primary)">';
          h += '<span style="flex:1">' + r.label + '</span>';
          h += '<span style="color:var(--fg-2);font-family:monospace;font-size:10.5px">' + M._esc(String(r.value || '—')) + '</span>';
          h += '</label>';
        });

        // Late reason
        if (isLate) {
          h += '<div class="wf-field" style="margin-top:12px"><label style="color:var(--dng);font-weight:900">⏰ دلیل تأخیر *</label>';
          h += '<select id="marLateReason" style="font-weight:800">';
          h += '<option value="">— انتخاب کنید —</option>';
          const reasons = await M._api('/api/mar/late-reasons');
          Object.entries(reasons.items || {}).forEach(([code, label]) => {
            h += '<option value="' + code + '">' + M._esc(label) + '</option>';
          });
          h += '</select></div>';
        }

        // Witness (high-alert)
        if (needsWitness) {
          h += '<div class="wf-field" style="margin-top:12px"><label style="color:var(--warn);font-weight:900">👥 شاهد (کد کاربری) *</label>';
          h += '<input type="text" id="marWitness" placeholder="username شاهد" required>';
          h += '</div>';
        }

        // Notes
        h += '<div class="wf-field" style="margin-top:12px"><label>یادداشت</label>';
        h += '<textarea id="marNotes" rows="2" placeholder="اختیاری"></textarea></div>';

        // Submit
        h += '<button class="btn btn-primary btn-block" style="padding:14px;margin-top:14px;font-weight:900;font-size:14px" onclick="NABZ.marUI._submitAdminister(\'' + marId + '\',' + (needsWitness ? 'true' : 'false') + ',' + (isLate ? 'true' : 'false') + ')">✅ توزیع دارو</button>';

        M._openSheet(h);
      } catch (e) { alert('خطا: ' + e.message); }
    },

    _barcodeCheck(input) {
      const el = document.getElementById('marBarcodeResult');
      if (!el) return;
      if (!input.value.trim()) { el.textContent = ''; return; }
      el.textContent = '✓ بارکد ثبت شد — 5 rights را تکمیل کنید';
      el.style.color = 'var(--ok)';
      // Auto-check the patient right
      const pCheckbox = document.querySelector('[data-right="patient"]');
      if (pCheckbox) pCheckbox.checked = true;
    },

    async _submitAdminister(marId, needsWitness, isLate) {
      const rights = {};
      let allChecked = true;
      document.querySelectorAll('[data-right]').forEach(cb => {
        rights[cb.dataset.right] = cb.checked;
        if (!cb.checked) allChecked = false;
      });
      if (!allChecked) return alert('همه ۵ rights باید تأیید شوند');

      const body = { fiveRights: rights };
      if (isLate) {
        const lr = document.getElementById('marLateReason');
        if (!lr || !lr.value) return alert('دلیل تأخیر الزامی است');
        body.lateReason = lr.value;
      }
      if (needsWitness) {
        const w = document.getElementById('marWitness');
        if (!w || !w.value.trim()) return alert('کد شاهد الزامی است');
        body.witnessedBy = w.value.trim();
      }
      const notes = document.getElementById('marNotes');
      if (notes && notes.value) body.notes = notes.value;

      try {
        const r = await M._api('/api/mar/' + marId + '/administer-advanced', {
          method: 'POST', body: JSON.stringify(body)
        });
        M._closeAll();
        NABZ._toast('✅ توزیع شد');
        // If PRN — prompt effectiveness
        if (r.prnEffectivenessPending) {
          setTimeout(() => M.prnEffectiveness(marId), 400);
        } else {
          M.show(null, null);
        }
      } catch (e) {
        // Special handling for allergy override
        if (String(e.message).indexOf('allergy_conflict') >= 0) {
          const override = prompt('⚠️ آلرژی: ' + e.message + '\n\nدلیل override (فقط attending):');
          if (override) {
            body.overrideReason = override;
            try {
              await M._api('/api/mar/' + marId + '/administer-advanced', {
                method: 'POST', body: JSON.stringify(body)
              });
              M._closeAll();
              NABZ._toast('✅ با override توزیع شد');
              M.show(null, null);
            } catch (e2) { alert('خطا: ' + e2.message); }
          }
        } else {
          alert('خطا: ' + e.message);
        }
      }
    },

    // ═══════════════════════════════════════════════════
    //  PRN EFFECTIVENESS
    // ═══════════════════════════════════════════════════
    async prnEffectiveness(marId) {
      let h = '<div class="bs-handle"></div>';
      h += '<div class="bs-hd"><div class="bs-title">📊 اثربخشی PRN</div>';
      h += '<button class="bs-close" onclick="this.closest(\'.bs-backdrop\').remove()">✕</button></div>';
      h += '<div class="hint warn" style="margin-bottom:14px">⚠️ الزام JCI: اثربخشی PRN باید ظرف ۱ ساعت مستند شود</div>';

      h += '<div class="wf-field"><label>مقیاس *</label>';
      h += '<select id="prnScale" style="font-weight:800">';
      Object.entries(SCALE_FA).forEach(([k, v]) => {
        h += '<option value="' + k + '">' + v + ' (0-10)</option>';
      });
      h += '</select></div>';

      h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">';
      h += '<div class="wf-field" style="margin:0"><label>قبل از دارو</label>';
      h += '<input type="number" id="prnBefore" min="0" max="10" value="8" style="font-size:24px;text-align:center;font-weight:900;padding:12px"></div>';
      h += '<div class="wf-field" style="margin:0"><label>بعد از دارو</label>';
      h += '<input type="number" id="prnAfter" min="0" max="10" style="font-size:24px;text-align:center;font-weight:900;padding:12px"></div>';
      h += '</div>';

      h += '<div id="prnDelta" style="text-align:center;padding:8px;background:var(--bg-2);border-radius:8px;margin-bottom:8px;font-size:13px;font-weight:800">—</div>';

      h += '<div class="wf-field"><label>یادداشت</label><textarea id="prnNotes" rows="2" placeholder="اختیاری"></textarea></div>';
      h += '<button class="btn btn-primary btn-block" style="padding:14px;margin-top:12px;font-weight:900" onclick="NABZ.marUI._submitEffectiveness(\'' + marId + '\')">✅ ثبت اثربخشی</button>';

      const s = M._openSheet(h);
      // Live delta
      ['prnBefore','prnAfter'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('input', () => {
          const before = parseFloat(document.getElementById('prnBefore').value) || 0;
          const after = parseFloat(document.getElementById('prnAfter').value);
          const delta = document.getElementById('prnDelta');
          if (isNaN(after)) { delta.textContent = '—'; return; }
          const d = before - after;
          const pct = before > 0 ? Math.round((d / before) * 100) : 0;
          delta.textContent = (d >= 0 ? '📉 بهبود ' : '📈 بدتر شد ') + Math.abs(d) + ' (' + pct + '%)';
          delta.style.color = d >= 2 ? 'var(--ok)' : d < 0 ? 'var(--dng)' : 'var(--warn)';
        });
      });
    },

    async _submitEffectiveness(marId) {
      const body = {
        scale: document.getElementById('prnScale').value,
        before: parseFloat(document.getElementById('prnBefore').value),
        after: parseFloat(document.getElementById('prnAfter').value),
        notes: document.getElementById('prnNotes').value
      };
      if (isNaN(body.before) || isNaN(body.after)) return alert('قبل و بعد را وارد کنید');
      try {
        await M._api('/api/mar/' + marId + '/prn-effectiveness', {
          method: 'POST', body: JSON.stringify(body)
        });
        M._closeAll();
        NABZ._toast('✅ اثربخشی ثبت شد');
        M.show(null, null);
      } catch (e) { alert('خطا: ' + e.message); }
    },

    // ═══════════════════════════════════════════════════
    //  SLIDING SCALE
    // ═══════════════════════════════════════════════════
    async slidingScale() {
      let h = '<div class="bs-handle"></div>';
      h += '<div class="bs-hd"><div class="bs-title">🧮 Sliding Scale — Insulin</div>';
      h += '<button class="bs-close" onclick="this.closest(\'.bs-backdrop\').remove()">✕</button></div>';

      let scales = { items: [] };
      try { scales = await M._api('/api/mar/sliding-scales'); } catch (_) {}

      h += '<div class="wf-field"><label>پروتکل</label>';
      h += '<select id="ssScale" style="font-weight:800">';
      (scales.items || []).forEach(s => {
        h += '<option value="' + s.code + '">' + M._esc(s.label) + '</option>';
      });
      h += '</select></div>';

      h += '<div class="wf-field"><label>قند خون (mg/dL) *</label>';
      h += '<input type="number" id="ssGlucose" placeholder="مثلاً 250" style="font-size:24px;text-align:center;font-weight:900;padding:12px" oninput="NABZ.marUI._autoCalcSS()"></div>';

      h += '<button class="btn btn-primary btn-block" style="padding:14px;margin-top:12px;font-weight:900" onclick="NABZ.marUI._calcSS()">🧮 محاسبه دوز</button>';
      h += '<div id="ssResult" style="margin-top:14px"></div>';

      M._openSheet(h);
    },

    _autoCalcSS() {
      const g = document.getElementById('ssGlucose').value;
      if (g && !isNaN(+g)) M._calcSS();
    },

    async _calcSS() {
      const g = parseFloat(document.getElementById('ssGlucose').value);
      if (isNaN(g) || g < 0) return;
      const scale = document.getElementById('ssScale').value;
      try {
        const r = await M._api('/api/mar/sliding-scale/calculate', {
          method: 'POST', body: JSON.stringify({ glucose: g, scale })
        });
        const el = document.getElementById('ssResult');
        const color = r.actionType === 'hypo' || r.actionType === 'hyper' ? 'dng' : r.units > 0 ? 'info' : 'ok';
        let h = '<div class="card" style="border-color:var(--' + color + ')">';
        h += '<div style="font-size:11px;color:var(--fg-2)">' + M._esc(r.scaleLabel) + '</div>';
        h += '<div style="font-size:36px;font-weight:900;color:var(--' + color + ');text-align:center;line-height:1.1;margin:8px 0">';
        if (r.units > 0) h += r.units + 'U';
        else h += '۰ واحد';
        h += '</div>';
        h += '<div style="font-size:11px;color:var(--fg-2);text-align:center">قند: ' + g + ' mg/dL</div>';
        if (r.note) h += '<div style="font-size:12px;margin-top:6px;padding:6px;background:var(--bg-3);border-radius:6px">' + M._esc(r.note) + '</div>';
        if (r.action) h += '<div style="font-size:12px;color:var(--dng);font-weight:900;margin-top:8px;padding:8px;background:var(--dng-soft);border-radius:6px">⚠️ ' + M._esc(r.action) + '</div>';
        if (r.units > 0 && r.drug) {
          h += '<div style="font-size:11px;margin-top:6px;text-align:center">دارو: <b>' + M._esc(r.drug) + '</b> · مسیر: <b>' + M._esc(r.route) + '</b></div>';
        }
        h += '</div>';
        el.innerHTML = h;
      } catch (e) {
        document.getElementById('ssResult').innerHTML = '<div class="empty">خطا: ' + M._esc(e.message) + '</div>';
      }
    },

    // ═══════════════════════════════════════════════════
    //  HANDOFF
    // ═══════════════════════════════════════════════════
    async handoff(p, d) {
      const m = document.getElementById('content');
      if (!d) {
        m.innerHTML = '<div style="text-align:center;padding:40px"><span class="spinner"></span></div>';
        try { d = await M._api('/api/mar/handoff'); }
        catch (e) { m.innerHTML = '<div class="empty">خطا: ' + M._esc(e.message) + '</div>'; return; }
      }
      const c = d.counts || {};
      let h = '<div class="sec-hd"><span>📋 تحویل شیفت — MAR</span>';
      h += '<span class="rd-mini">' + ((d.window && d.window.hours) || 8) + ' ساعت</span></div>';

      h += '<div class="rd-stats" style="grid-template-columns:repeat(3,1fr);margin-bottom:12px">';
      h += '<div class="rd-stat ok"><div class="v">' + (c.given || 0) + '</div><div class="l">داده‌شده</div></div>';
      h += '<div class="rd-stat ' + ((c.missed || 0) > 0 ? 'dng' : '') + '"><div class="v">' + (c.missed || 0) + '</div><div class="l">Missed</div></div>';
      h += '<div class="rd-stat ' + ((c.prnWithoutEffectiveness || 0) > 0 ? 'warn' : '') + '"><div class="v">' + (c.prnWithoutEffectiveness || 0) + '</div><div class="l">PRN بی‌ارزیابی</div></div>';
      h += '</div>';

      h += '<div class="rd-stats" style="grid-template-columns:repeat(3,1fr);margin-bottom:12px">';
      h += '<div class="rd-stat info"><div class="v">' + (c.highAlertGiven || 0) + '</div><div class="l">High-Alert</div></div>';
      h += '<div class="rd-stat"><div class="v">' + (c.lateGiven || 0) + '</div><div class="l">تأخیر</div></div>';
      h += '<div class="rd-stat"><div class="v">' + (c.pending || 0) + '</div><div class="l">در انتظار</div></div>';
      h += '</div>';

      // Missed details
      if (d.details.missed && d.details.missed.length) {
        h += '<div class="sec-hd" style="margin-top:14px"><span style="color:var(--dng)">⚠️ Missed (' + d.details.missed.length + ')</span></div>';
        d.details.missed.forEach(x => {
          h += '<div class="row hi" style="padding:8px 10px;margin-bottom:4px">';
          h += '<div style="font-weight:800;font-size:12px">' + M._esc(x.drugName) + '</div>';
          h += '<div style="font-size:10.5px;color:var(--fg-2)">' + M._esc(x.patientName) + ' · ' + x.minutesLate + ' دقیقه</div>';
          h += '</div>';
        });
      }

      // PRN missing effectiveness
      if (d.details.prnWithoutEffectiveness && d.details.prnWithoutEffectiveness.length) {
        h += '<div class="sec-hd" style="margin-top:14px"><span style="color:var(--warn)">📊 PRN بدون اثربخشی</span></div>';
        d.details.prnWithoutEffectiveness.forEach(x => {
          h += '<div class="row md" style="padding:8px 10px;margin-bottom:4px;cursor:pointer" onclick="NABZ.marUI.prnEffectiveness(\'' + x.id + '\')">';
          h += '<div style="font-weight:800;font-size:12px">' + M._esc(x.drugName) + '</div>';
          h += '<div style="font-size:10.5px;color:var(--fg-2)">' + M._esc(x.patientName) + '</div>';
          h += '</div>';
        });
      }

      // High-alert given
      if (d.details.highAlertGiven && d.details.highAlertGiven.length) {
        h += '<div class="sec-hd" style="margin-top:14px"><span>⚠️ High-Alert داده‌شده</span></div>';
        d.details.highAlertGiven.forEach(x => {
          h += '<div class="row lo" style="padding:8px 10px;margin-bottom:4px">';
          h += '<div style="font-weight:800;font-size:12px">' + M._esc(x.drugName) + ' — ' + M._esc(x.dose) + '</div>';
          h += '<div style="font-size:10.5px;color:var(--fg-2)">' + M._esc(x.patientName) + (x.witnessedBy ? ' · شاهد: ' + M._esc(x.witnessedBy) : ' · ⚠️ بدون شاهد') + '</div>';
          h += '</div>';
        });
      }

      // Late given
      if (d.details.lateGiven && d.details.lateGiven.length) {
        h += '<div class="sec-hd" style="margin-top:14px"><span style="color:var(--warn)">⏰ تأخیرها</span></div>';
        d.details.lateGiven.forEach(x => {
          h += '<div class="row md" style="padding:8px 10px;margin-bottom:4px">';
          h += '<div style="font-weight:800;font-size:12px">' + M._esc(x.drugName) + '</div>';
          h += '<div style="font-size:10.5px;color:var(--fg-2)">' + M._esc(x.patientName) + ' · ' + x.minutesLate + ' دقیقه · ' + M._esc(x.reason) + '</div>';
          h += '</div>';
        });
      }

      // Print button
      h += '<button class="btn btn-block" style="padding:12px;margin-top:14px" onclick="NABZ.marUI._printHandoff()">🖨 چاپ خلاصه</button>';

      m.innerHTML = h;
      NABZ.state.current = p ? p.id : 'mar_advanced.handoff';
    },

    _printHandoff() {
      const m = document.getElementById('content');
      const user = NABZ.state.user;
      let html = '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="UTF-8"><title>تحویل شیفت — MAR</title>';
      html += '<style>@page{size:A4;margin:15mm}body{font-family:Vazirmatn,Tahoma,sans-serif;font-size:11px}h1{font-size:16px;color:#0891b2}table{width:100%;border-collapse:collapse;margin-top:15px}th,td{border:1px solid #cbd5e1;padding:6px;font-size:10px}th{background:#e0f2fe}</style>';
      html += '</head><body><h1>📋 تحویل شیفت — MAR</h1>';
      html += '<p>' + (user ? user.fullName : '') + ' — ' + new Date().toLocaleString('fa-IR') + '</p>';
      html += m.innerHTML.replace(/<button[^>]*>.*?<\/button>/g, '').replace(/class="[^"]*"/g, '');
      html += '</body></html>';
      const w = window.open('', '_blank');
      if (!w) return alert('پاپ‌آپ مسدود است');
      w.document.open(); w.document.write(html); w.document.close();
      setTimeout(() => { try { w.focus(); w.print(); } catch(_) { alert('Ctrl+P'); } }, 500);
    },

    // ═══════════════════════════════════════════════════
    //  HIGH-ALERT AUDIT
    // ═══════════════════════════════════════════════════
    async highAlertAudit() {
      try {
        const d = await M._api('/api/mar/high-alert-audit?days=7');
        let h = '<div class="bs-handle"></div>';
        h += '<div class="bs-hd"><div class="bs-title">🔍 High-Alert Audit — ۷ روز</div>';
        h += '<button class="bs-close" onclick="this.closest(\'.bs-backdrop\').remove()">✕</button></div>';

        const compliance = d.compliancePct || 100;
        const color = compliance >= 95 ? 'ok' : compliance >= 80 ? 'warn' : 'dng';
        h += '<div class="card" style="text-align:center;border-color:var(--' + color + ');margin-bottom:12px">';
        h += '<div style="font-size:48px;font-weight:900;color:var(--' + color + ')">' + compliance + '%</div>';
        h += '<div style="font-size:11px;color:var(--fg-2)">Witness Compliance</div>';
        h += '</div>';

        h += '<div class="rd-stats" style="grid-template-columns:repeat(3,1fr);margin-bottom:12px">';
        h += '<div class="rd-stat"><div class="v">' + d.totalHighAlert + '</div><div class="l">کل High-Alert</div></div>';
        h += '<div class="rd-stat ok"><div class="v">' + d.withWitness + '</div><div class="l">با شاهد</div></div>';
        h += '<div class="rd-stat ' + (d.withoutWitness > 0 ? 'dng' : '') + '"><div class="v">' + d.withoutWitness + '</div><div class="l">بدون شاهد</div></div>';
        h += '</div>';

        if (d.violations.length) {
          h += '<div style="font-size:12px;font-weight:900;color:var(--dng);margin:12px 0 6px">⚠️ نقض‌ها</div>';
          d.violations.forEach(v => {
            h += '<div class="row hi" style="padding:8px 10px;margin-bottom:4px">';
            h += '<div style="font-weight:800;font-size:12px">' + M._esc(v.drugName) + '</div>';
            h += '<div style="font-size:10.5px;color:var(--fg-2)">' + M._esc(v.patientName) + ' · ' + M._esc(v.administeredBy || '') + ' · ' + M._fmtTime(v.administeredAt) + '</div>';
            h += '</div>';
          });
        }

        M._openSheet(h);
      } catch (e) { alert('خطا: ' + e.message); }
    },

    // ═══════════════════════════════════════════════════
    //  REFUSE
    // ═══════════════════════════════════════════════════
    async refuse(marId) {
      const reason = prompt('دلیل رد دوز:');
      if (!reason) return;
      try {
        await M._api('/api/clinical/mar/' + marId + '/refuse', {
          method: 'POST', body: JSON.stringify({ reason })
        });
        NABZ._toast('✅ ثبت شد');
        M.show(null, null);
      } catch (e) { alert('خطا: ' + e.message); }
    }
  };

  // ═══ Bootstrap ═══
  let waitCount = 0;
  function ready(fn) {
    if (window.NABZ && typeof NABZ.show === 'function') return fn();
    if (++waitCount >= 60) return console.warn('[mar-ui] timeout');
    setTimeout(() => ready(fn), 100);
  }

  ready(() => {
    NABZ.marUI = M;

    if (typeof NABZ.registerKind === 'function') {
      NABZ.registerKind('mar_v2', (p, d) => M.show(p, d));
      NABZ.registerKind('mar_handoff', (p, d) => M.handoff(p, d));
    }

    // Handle showItem for MAR
    const prevShowItem = NABZ.showItem;
    if (typeof prevShowItem === 'function') {
      NABZ.showItem = function(pid, iid) {
        if (pid === 'clinical.mar' || pid === 'mar_advanced.detailed') {
          return M.administer(iid);
        }
        return prevShowItem.apply(NABZ, arguments);
      };
    }

    console.log('[mar-ui] loaded ✓ — MAR Advanced (ISMP 2024, JCI, sliding scale)');
  });
})();
