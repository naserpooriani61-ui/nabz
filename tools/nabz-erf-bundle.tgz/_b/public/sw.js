// ═══════════════════════════════════════════════════════════
//  NABZ Service Worker v9 — Offline-First
//  Strategy:
//    Static assets  → cache-first + background update
//    API GET        → network-first + cache fallback
//    API mutations  → network only (client queues failed)
//    Navigation     → cache-first with index fallback
// ═══════════════════════════════════════════════════════════
const VERSION = 1794672953210;
const STATIC_CACHE = 'nabz-static-v' + VERSION;
const API_CACHE    = 'nabz-api-v' + VERSION;

const STATIC_ASSETS = [
  '/', '/index.html', '/style.css', '/manifest.webmanifest',
  '/app.js', '/extra.js',
  '/voice.js', '/voice-init.js',
  '/documents.js', '/scanner.js', '/ops2.js', '/live.js',
  '/offline.js', '/offline-init.js',
  '/cdss.js',
  '/flow.js',
  '/sa.js',
  '/sa-init.js', '/encounters-ui.js']

// APIs that MUST NOT be cached (auth, live stream, huge audio)
const NO_CACHE_API = [
  /^\/api\/stream/,
  /^\/api\/auth\//,
  /^\/api\/voice\/note\/[^/]+\/audio/,
  /^\/api\/neural\/alerts/, '/clinical-workflow-ui.js']

// ─── Install ───
self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(STATIC_CACHE).then(c => c.addAll(STATIC_ASSETS).catch(err => {
      console.warn('[sw] partial static cache:', err.message);
    }))
  );
  self.skipWaiting();
});

// ─── Activate ───
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(k => k !== STATIC_CACHE && k !== API_CACHE)
          .map(k => { console.log('[sw] deleting old cache:', k); return caches.delete(k); })
    ))
  );
  self.clients.claim();
});

// ─── Fetch ───
self.addEventListener('fetch', (e) => {
  const req = e.request;
  let url;
  try { url = new URL(req.url); } catch (_) { return; }

  // Only same-origin
  if (url.origin !== location.origin) return;

  // API
  if (url.pathname.startsWith('/api/')) {
    if (NO_CACHE_API.some(p => p.test(url.pathname))) return;
    if (req.method !== 'GET') return;   // mutations handled by client
    e.respondWith(handleAPIGet(req));
    return;
  }

  // Static / navigation
  if (req.method === 'GET') {
    e.respondWith(handleStatic(req));
  }
});

// ═══════════════════════════════════════════════════════════
//  Static — cache-first + background update
// ═══════════════════════════════════════════════════════════
async function handleStatic(req) {
  const cached = await caches.match(req);

  // Fire network update regardless (stale-while-revalidate)
  const updatePromise = fetch(req).then(res => {
    if (res && res.ok) {
      const clone = res.clone();
      caches.open(STATIC_CACHE).then(c => c.put(req, clone));
    }
    return res;
  }).catch(() => null);

  if (cached) { updatePromise; return cached; }

  const fresh = await updatePromise;
  if (fresh) return fresh;

  // Offline + uncached
  if (req.mode === 'navigate') {
    const index = await caches.match('/index.html');
    if (index) return index;
  }
  return new Response('آفلاین — فایل در دسترس نیست', {
    status: 503,
    headers: { 'Content-Type': 'text/plain; charset=utf-8' }
  });
}

// ═══════════════════════════════════════════════════════════
//  API GET — network-first + cache fallback
// ═══════════════════════════════════════════════════════════
async function handleAPIGet(req) {
  try {
    const res = await fetch(req);
    if (res && res.ok) {
      const clone = res.clone();
      caches.open(API_CACHE).then(c => c.put(req, clone));
    }
    return res;
  } catch (err) {
    // Network failed — try cache
    const cached = await caches.match(req);
    if (cached) {
      const body = await cached.text();
      const headers = new Headers(cached.headers);
      headers.set('X-Nabz-Cached', '1');
      headers.set('X-Nabz-Cached-At', new Date().toISOString());
      return new Response(body, {
        status: cached.status,
        statusText: cached.statusText,
        headers
      });
    }
    // No cache — return error JSON
    return new Response(JSON.stringify({
      ok: false,
      error: 'offline_no_cache',
      _offline: true
    }), {
      status: 503,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

// ─── Message handler (for cache clearing from client) ───
self.addEventListener('message', (e) => {
  const msg = e.data || {};
  if (msg.type === 'CLEAR_ALL') {
    Promise.all([
      caches.delete(STATIC_CACHE),
      caches.delete(API_CACHE)
    ]).then(() => {
      if (e.source) e.source.postMessage({ type: 'CLEARED' });
    });
  }
});
