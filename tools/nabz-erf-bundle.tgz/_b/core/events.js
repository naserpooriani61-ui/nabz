'use strict';
const store = require('./store');
const _subs = {}, _events = [];
function on(evt, fn) { (_subs[evt] = _subs[evt] || []).push(fn); }
function emit(evt, payload) {
  const record = { id: store.uid('evt'), event: evt, at: new Date().toISOString(),
                   actor: payload.actor || null, data: payload };
  _events.push(record);
  if (_events.length > 5000) _events.shift();
  // Persist daily
  try {
    const day = record.at.slice(0, 10);
    store.put('event_log_' + day, record);
  } catch (_) {}
  // Notify subscribers
  const fns = (_subs[evt] || []).concat(_subs['*'] || []);
  for (const fn of fns) { try { fn(payload); } catch (e) { console.error('[sub]', evt, e.message); } }
  return record;
}
function recent(limit) { return _events.slice(-(limit || 100)).reverse(); }
function since(iso) { return _events.filter(e => e.at >= iso); }
module.exports = { on, emit, recent, since };
