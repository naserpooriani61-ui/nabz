
// ═══════════════════════════════════════════════════════════
//  NABZ — Emergency Department UI (ERF v2, specialized)
//  - NEDOCS overcrowding score
//  - 6-zone board with real-time occupancy
//  - ESI triage with auto-suggest
//  - Live wait-time timers with ESI threshold alerts
//  - Boarding tracker
//  - Pre-hospital ETA countdown
//  - Referral (in/out) workflow
// ═══════════════════════════════════════════════════════════
(function() {
  'use strict';

  var ZONES = [
    { code:'CPR',    label:'CPR',       icon:'💔', group:'resuscitation', critical:true,  color:'#ef4444' },
    { code:'TRAUMA', label:'تروما',     icon:'🩸', group:'resuscitation', critical:true,  color:'#dc2626' },
    { code:'FAST',   label:'FAST',      icon:'⚡', group:'urgent',        critical:false, color:'#0ea5e9' },
    { code:'ACUTE1', label:'حاد ۱',     icon:'🏥', group:'urgent',        critical:false, color:'#f59e0b' },
    { code:'ACUTE2', label:'حاد ۲',     icon:'🏥', group:'urgent',        critical:false, color:'#f59e0b' },
    { code:'CAST',   label:'گچ',        icon:'🦴', group:'minor',         critical:false, color:'#10b981' }
  ];
  var ESI = [
    { level:1, label:'احیای فوری',  color:'dng',  maxWaitMin:0,   examples:'ایست قلبی، شوک، GCS ≤ 8' },
    { level:2, label:'اورژانسی',    color:'dng',  maxWaitMin:10,  examples:'درد قفسه سینه، دیسترس تنفسی' },
    { level:3, label:'فوری',        color:'warn', maxWaitMin:30,  examples:'درد شدید، تب بالا' },
    { level:4, label:'غیرفوری',     color:'info', maxWaitMin:60,  examples:'درد خفیف، زخم سطحی' },
    { level:5, label:'سرپایی',      color:'ok',   maxWaitMin:120, examples:'علائم خفیف، نسخه' }
  ];
  var ARRIVAL = [
    { code:'walk_in', label:'مراجعه شخصی', icon:'🚶' },
    { code:'ambulance', label:'آمبولانس ۱۱۵', icon:'🚑' },
    { code:'private_amb', label:'آمبولانس خصوصی', icon:'🚐' },
    { code:'referral', label:'ارجاع', icon:'↪️' },
    { code:'mci', label:'سانحه', icon:'🌐' }
  ];
  var STATUS_FA = {
    waiting_triage:'منتظر تریاژ', waiting_doctor:'منتظر پزشک',
    boarding:'بستری موقت', admitted:'بستری', discharged:'ترخیص',
    transferred:'منتقل', deceased:'فوت', closed:'بسته'
  };
  var STATUS_CLS = {
    waiting_triage:'dng', waiting_doctor:'warn', boarding:'info',
    admitted:'ok', discharged:'ok', transferred:'info', deceased:'dng', closed:''
  };

  var E = {
    _api: function(p, o) { return NABZ._api(p, o); },
    _esc: function(s) { return NABZ._esc(s); },
    _state: { liveTimer: null, tickInterval: null, lastDash: null, view: 'dashboard' },

    // ═══ Helpers ═══
    _fmt(sec) {
      if (sec < 0) sec = 0;
      const h = Math.floor(sec / 3600);
      const m = Math.floor((sec % 3600) / 60);
      const s = sec % 60;
      if (h > 0) return h + 'h ' + m + 'm';
      if (m > 0) return m + ':' + String(s).padStart(2, '0');
      return s + 's';
    },
    _closeAll() { document.querySelectorAll('.bs-backdrop').forEach(el => el.remove()); },
    _openSheet(html, opts) {
      opts = opts || {};
      const sheet = document.createElement('div');
      sheet.className = 'bs-backdrop';
      sheet.onclick = e => { if (e.target === sheet && !opts.noClose) sheet.remove(); };
      const c = document.createElement('div');
      c.className = 'bs-sheet';
      c.style.maxHeight = '96vh';
      c.innerHTML = html;
      sheet.appendChild(c);
      document.body.appendChild(sheet);
      requestAnimationFrame(() => sheet.classList.add('show'));
      return { sheet, content: c };
    },

    // ═══ LIVE TIMER LOOP ═══
    _startTimers() {
      if (E._state.tickInterval) clearInterval(E._state.tickInterval);
      const update = () => {
        const now = Date.now();
        document.querySelectorAll('[data-elapsed-from]').forEach(el => {
          try {
            const start = new Date(el.dataset.elapsedFrom).getTime();
            const sec = Math.floor((now - start) / 1000);
            const esi = parseInt(el.dataset.esi || '3', 10);
            const maxMin = (ESI[esi - 1] || {}).maxWaitMin || 60;
            const maxSec = maxMin * 60;
            el.textContent = E._fmt(sec);
            if (maxSec > 0 && sec > maxSec) {
              el.style.color = 'var(--dng)';
              el.style.fontWeight = '900';
            } else if (maxSec > 0 && sec > maxSec * 0.8) {
              el.style.color = 'var(--warn)';
              el.style.fontWeight = '800';
            } else {
              el.style.color = '';
              el.style.fontWeight = '';
            }
          } catch (_) {}
        });
        document.querySelectorAll('[data-countdown-to]').forEach(el => {
          try {
            const target = new Date(el.dataset.countdownTo).getTime();
            const sec = Math.floor((target - now) / 1000);
            if (sec <= 0) {
              el.textContent = 'رسید';
              el.style.color = 'var(--dng)';
            } else {
              el.textContent = E._fmt(sec);
              el.style.color = sec < 300 ? 'var(--warn)' : '';
            }
          } catch (_) {}
        });
      };
      update();
      E._state.tickInterval = setInterval(update, 1000);
    },

    _stopTimers() {
      if (E._state.tickInterval) clearInterval(E._state.tickInterval);
      E._state.tickInterval = null;
    },

    // ═══ NEDOCS Score ═══
    _nedocs(d) {
      // NEDOCS: 85.8 * (ED patients / ED beds) + 600 * (admitted / hospital beds) + 5.5 * ventilated + 12.5 * longest wait (h) - 200
      const totalED = (d.stats && d.stats.totalVisits) || 0;
      const edBeds = 99; // total from zones (5+5+30+15+40+4)
      const admitted = (d.stats && d.stats.boarding) || 0;
      const hospitalBeds = 384; // from sina wards
      const ventilated = 0; // would need to derive
      // Longest wait from boarding or waiting
      let longestWaitHr = 0;
      (d.boardingDetail || []).forEach(b => {
        const wait = (Date.now() - new Date(b.arrivalAt).getTime()) / 3600000;
        if (wait > longestWaitHr) longestWaitHr = wait;
      });
      const score = 85.8 * (totalED / edBeds) +
                    600 * (admitted / hospitalBeds) +
                    5.5 * ventilated +
                    12.5 * longestWaitHr - 200;
      const s = Math.max(0, Math.round(score));
      let level, label, color;
      if (s <= 20) { level = 0; label = 'آرام'; color = 'ok'; }
      else if (s <= 60) { level = 1; label = 'شلوغ'; color = 'info'; }
      else if (s <= 100) { level = 2; label = 'خیلی شلوغ'; color = 'warn'; }
      else if (s <= 140) { level = 3; label = 'ازدحام'; color = 'dng'; }
      else { level = 4; label = 'بحرانی'; color = 'dng'; }
      return { score: s, level, label, color };
    },

    // ═══════════════════════════════════════════════════
    //  DASHBOARD
    // ═══════════════════════════════════════════════════
    async dashboard(p, d) {
      const m = document.getElementById('content');
      if (!d) {
        m.innerHTML = '<div style="text-align:center;padding:40px"><span class="spinner"></span></div>';
        try { d = await E._api('/api/erf/overview'); }
        catch (e) { m.innerHTML = '<div class="empty">خطا: ' + E._esc(e.message) + '</div>'; return; }
      }
      E._state.lastDash = d;
      E._state.view = 'dashboard';

      // Fetch prehospital + referrals in parallel
      let preHosp = { items: [] }, refs = { items: [] };
      try {
        const [ph, rf] = await Promise.all([
          E._api('/api/erf/prehospital').catch(() => ({ items: [] })),
          E._api('/api/erf/referral').catch(() => ({ items: [] }))
        ]);
        preHosp = ph; refs = rf;
      } catch (_) {}

      const nedocs = E._nedocs(d);
      const s = d.stats || {};

      let h = '';
      // Header
      h += '<div class="sec-hd"><span>🚨 اورژانس — داشبورد</span>';
      h += '<span class="rd-mini">' + new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }) + '</span></div>';

      // NEDOCS banner
      h += '<div class="card" style="background:linear-gradient(135deg,' + 
           (nedocs.color === 'dng' ? 'rgba(239,68,68,0.15)' : nedocs.color === 'warn' ? 'rgba(245,158,11,0.15)' : nedocs.color === 'info' ? 'rgba(59,130,246,0.12)' : 'rgba(16,185,129,0.12)') +
           ',transparent);border-color:var(--' + nedocs.color + ');margin-bottom:12px">';
      h += '<div style="display:flex;justify-content:space-between;align-items:center">';
      h += '<div><div style="font-size:11px;color:var(--fg-2);font-weight:800">NEDOCS — شاخص ازدحام</div>';
      h += '<div style="font-size:28px;font-weight:900;color:var(--' + nedocs.color + ');line-height:1.1">' + nedocs.score + '</div>';
      h += '<div style="font-size:12px;font-weight:800;color:var(--' + nedocs.color + ')">' + nedocs.label + '</div></div>';
      h += '<div style="text-align:left;font-size:11px;color:var(--fg-2);line-height:1.7">';
      h += '<div>بیماران: <b>' + (s.totalVisits || 0) + '</b></div>';
      h += '<div>Boarding: <b>' + (s.boarding || 0) + '</b></div>';
      h += '<div>منتظر: <b>' + ((s.waitingTriage || 0) + (s.waitingDoctor || 0)) + '</b></div>';
      h += '</div></div></div>';

      // Critical alerts
      if ((s.activeCodes || 0) + (s.activeMCI || 0) > 0) {
        h += '<div style="background:var(--dng-soft);border:2px solid var(--dng);border-radius:12px;padding:12px;margin-bottom:12px;animation:pulse-critical 2s infinite">';
        h += '<div style="font-size:14px;font-weight:900;color:var(--dng)">🚨 هشدار فعال</div>';
        if (s.activeCodes > 0) h += '<div style="font-size:12px;margin-top:4px">' + s.activeCodes + ' کد فعال</div>';
        if (s.activeMCI > 0) h += '<div style="font-size:12px">MCI فعال</div>';
        h += '</div>';
      }

      // Zone board
      h += '<div class="sec-hd"><span>🏥 زون‌ها</span></div>';
      h += '<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-bottom:12px">';
      (d.zones || []).forEach(z => {
        const info = ZONES.find(x => x.code === z.code) || {};
        const pct = z.occupancyPct || 0;
        const cls = pct >= 90 ? 'dng' : pct >= 70 ? 'warn' : 'ok';
        h += '<button onclick="NABZ.erfUI.showZone(\'' + z.code + '\')" ';
        h += 'style="background:var(--bg-2);border:2px solid var(--' + cls + ');border-radius:10px;padding:10px;font-family:inherit;color:var(--fg);text-align:right;cursor:pointer">';
        h += '<div style="display:flex;justify-content:space-between;align-items:center">';
        h += '<div style="font-size:18px">' + (info.icon || '🏥') + '</div>';
        h += '<div style="font-size:12px;font-weight:900;color:var(--' + cls + ')">' + z.bedsOccupied + '/' + z.bedsTotal + '</div>';
        h += '</div>';
        h += '<div style="font-size:11px;font-weight:800;margin-top:4px">' + E._esc(z.label) + '</div>';
        h += '<div class="progress" style="margin-top:4px;height:4px"><div class="progress-fill ' + cls + '" style="width:' + pct + '%"></div></div>';
        h += '</button>';
      });
      h += '</div>';

      // ESI distribution
      h += '<div class="sec-hd"><span>📊 توزیع ESI</span></div>';
      h += '<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px;margin-bottom:12px">';
      ESI.forEach(e => {
        const count = (s.esiDist || {})[e.level] || 0;
        h += '<div style="text-align:center;padding:8px 4px;background:var(--bg-2);border-radius:8px;border:1px solid var(--' + e.color + ')">';
        h += '<div style="font-size:18px;font-weight:900;color:var(--' + e.color + ')">' + count + '</div>';
        h += '<div style="font-size:9px;color:var(--fg-2);font-weight:700">ESI ' + e.level + '</div>';
        h += '</div>';
      });
      h += '</div>';

      // Pre-hospital incoming
      const incoming = (preHosp.items || []).filter(x => x.status === 'incoming');
      if (incoming.length) {
        h += '<div class="sec-hd"><span>🚑 در راه (' + incoming.length + ')</span></div>';
        incoming.forEach(x => {
          h += '<div class="row hi" onclick="NABZ.erfUI._viewPreHospital(\'' + x.id + '\')">';
          h += '<div class="row-hd"><div class="row-title">' + E._esc(x.patientName) + '</div>';
          h += '<span class="pill dng">ETA <span data-countdown-to="' + new Date(Date.now() + (x.etaMinutes || 0) * 60000).toISOString() + '">' + (x.etaMinutes || 0) + 'm</span></span></div>';
          h += '<div class="row-meta">' + E._esc(x.chiefComplaint || '—') + '</div>';
          h += '<div class="row-meta">آمبولانس: ' + E._esc(x.ambulanceCode || '—') + '</div>';
          h += '</div>';
        });
      }

      // Referrals active
      const activeRefs = (refs.items || []).filter(x => ['pending_arrival','pending_send'].includes(x.status));
      if (activeRefs.length) {
        h += '<div class="sec-hd"><span>↪️ ارجاع فعال (' + activeRefs.length + ')</span></div>';
        activeRefs.slice(0, 5).forEach(x => {
          h += '<div class="row md" onclick="NABZ.erfUI._viewReferral(\'' + x.id + '\')">';
          h += '<div class="row-hd"><div class="row-title">' + E._esc(x.patientName) + '</div>';
          h += '<span class="pill ' + (x.direction === 'incoming' ? 'info' : 'warn') + '">' + (x.direction === 'incoming' ? 'ورودی' : 'خروجی') + '</span></div>';
          h += '<div class="row-meta">' + E._esc(x.reason || '—') + '</div>';
          h += '</div>';
        });
      }

      // Quick actions
      h += '<div class="sec-hd"><span>⚡ اقدام سریع</span></div>';
      h += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:12px">';
      h += '<button class="btn" style="padding:14px 6px;display:flex;flex-direction:column;gap:4px;align-items:center;font-size:10.5px" onclick="NABZ.erfUI.registerVisit()"><span style="font-size:22px">👤</span>پذیرش</button>';
      h += '<button class="btn" style="padding:14px 6px;display:flex;flex-direction:column;gap:4px;align-items:center;font-size:10.5px" onclick="NABZ.erfUI.newPreHospital()"><span style="font-size:22px">🚑</span>پیش‌بیمارستانی</button>';
      h += '<button class="btn" style="padding:14px 6px;display:flex;flex-direction:column;gap:4px;align-items:center;font-size:10.5px" onclick="NABZ.erfUI.newReferral()"><span style="font-size:22px">↪️</span>ارجاع</button>';
      h += '</div>';

      m.innerHTML = h;
      E._startTimers();
      E._subscribeLive();
    },

    // ═══════════════════════════════════════════════════
    //  ZONE DETAIL
    // ═══════════════════════════════════════════════════
    async showZone(zoneCode) {
      const m = document.getElementById('content');
      m.innerHTML = '<div style="text-align:center;padding:40px"><span class="spinner"></span></div>';
      try {
        const d = await E._api('/api/erf/zones/' + zoneCode + '/beds');
        const zone = d.zone;
        const info = ZONES.find(x => x.code === zoneCode) || {};

        let h = '<div class="sec-hd"><span>' + (info.icon || '🏥') + ' ' + E._esc(zone.label) + '</span>';
        h += '<span class="rd-mini">' + d.beds.length + ' تخت</span></div>';
        h += '<button class="btn" style="padding:8px 12px;font-size:11px;margin-bottom:12px" onclick="NABZ.erfUI.dashboard()">← داشبورد</button>';

        // Bed grid
        h += '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(80px,1fr));gap:8px">';
        d.beds.forEach(b => {
          const isOccupied = b.status === 'occupied';
          const isCritical = b.isCritical;
          const color = isOccupied ? 'var(--dng)' : b.status === 'cleaning' ? 'var(--warn)' : 'var(--ok)';
          h += '<div class="card" style="padding:8px;text-align:center;border-top:3px solid ' + color + ';cursor:pointer"';
          if (isOccupied && b.patientName) {
            h += ' onclick="NABZ.erfUI._viewBed(\'' + b.id + '\',\'' + zoneCode + '\')"';
          } else {
            h += ' onclick="NABZ.erfUI._pickBedForAdmit(\'' + b.id + '\',\'' + zoneCode + '\')"';
          }
          h += '>';
          h += '<div style="font-size:10px;font-weight:900;color:var(--primary)">' + E._esc(b.bedNumber) + '</div>';
          if (isOccupied) {
            h += '<div style="font-size:10px;font-weight:700;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + E._esc(b.patientName || '?') + '</div>';
            if (isCritical) h += '<div style="font-size:9px;color:var(--dng)">🔴</div>';
          } else {
            h += '<div style="font-size:9px;color:var(--fg-3);margin-top:2px">' + (b.status === 'cleaning' ? '🧹' : '✓') + '</div>';
          }
          h += '</div>';
        });
        h += '</div>';

        m.innerHTML = h;
      } catch (e) {
        m.innerHTML = '<div class="empty">خطا: ' + E._esc(e.message) + '</div>';
      }
    },

    async _viewBed(bedId, zoneCode) {
      // Find the visit for this bed
      try {
        const d = await E._api('/api/erf/overview');
        const visits = await E._api('/api/erf/visit').catch(() => ({ items: [] }));
        // Find active visit with this bedId
        const visit = ((d.stats && d.stats.activeVisits) || []).find(v => v.bedId === bedId) ||
                      (visits.items || []).find(v => v.bedId === bedId && !['closed','discharged'].includes(v.status));
        if (!visit) return alert('بیمار یافت نشد');
        E._viewVisit(visit.id);
      } catch (e) { alert('خطا: ' + e.message); }
    },

    async _viewVisit(visitId) {
      try {
        // We don't have a direct endpoint - fetch from list
        const all = await E._api('/api/erf/prehospital').catch(() => ({ items: [] }));
        // Try to find in visits via internal endpoint - fall back to disposition modal
        E._openDispositionModal(visitId);
      } catch (e) { alert('خطا: ' + e.message); }
    },

    async _pickBedForAdmit(bedId, zoneCode) {
      // Find waiting patients to assign
      try {
        const visits = await E._api('/api/erf/overview');
        // Show list of waiting patients from dashboard detail
        const d = E._state.lastDash || visits;
        E._openAssignPatientModal(bedId, zoneCode);
      } catch (e) { alert('خطا: ' + e.message); }
    },

    // ═══════════════════════════════════════════════════
    //  REGISTER NEW VISIT
    // ═══════════════════════════════════════════════════
    registerVisit() {
      let h = '<div class="bs-handle"></div>';
      h += '<div class="bs-hd"><div class="bs-title">👤 پذیرش اورژانس</div>';
      h += '<button class="bs-close" onclick="this.closest(\'.bs-backdrop\').remove()">✕</button></div>';
      h += '<div class="wf-field"><label>نام بیمار *</label><input type="text" id="erfName" placeholder="نام و نام خانوادگی"></div>';
      h += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:8px">';
      h += '<div class="wf-field" style="margin:0"><label>سن</label><input type="number" id="erfAge" min="0" max="130"></div>';
      h += '<div class="wf-field" style="margin:0"><label>جنسیت</label><select id="erfSex"><option value="male">مرد</option><option value="female">زن</option></select></div>';
      h += '<div class="wf-field" style="margin:0"><label>کد ملی</label><input type="text" id="erfNID"></div>';
      h += '</div>';
      h += '<div class="wf-field"><label>شکایت اصلی *</label><textarea id="erfCC" rows="2" placeholder="مثلاً: درد قفسه سینه از ۲ ساعت پیش"></textarea></div>';
      h += '<div class="wf-field"><label>نحوه ورود</label><select id="erfArrival">';
      ARRIVAL.forEach(a => { h += '<option value="' + a.code + '">' + a.icon + ' ' + a.label + '</option>'; });
      h += '</select></div>';

      h += '<div style="font-size:11px;font-weight:900;color:var(--primary);margin:12px 0 6px;padding-bottom:4px;border-bottom:1px solid var(--border)">📊 ویتال (برای پیشنهاد ESI)</div>';
      h += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px">';
      h += '<div class="wf-field" style="margin:0"><label>HR</label><input type="number" id="erfHR" placeholder="bpm"></div>';
      h += '<div class="wf-field" style="margin:0"><label>SBP</label><input type="number" id="erfSBP" placeholder="mmHg"></div>';
      h += '<div class="wf-field" style="margin:0"><label>RR</label><input type="number" id="erfRR" placeholder="/min"></div>';
      h += '<div class="wf-field" style="margin:0"><label>Temp</label><input type="number" step="0.1" id="erfTemp" placeholder="°C"></div>';
      h += '<div class="wf-field" style="margin:0"><label>SpO₂</label><input type="number" id="erfSpO2" placeholder="%"></div>';
      h += '<div class="wf-field" style="margin:0"><label>GCS</label><input type="number" id="erfGCS" placeholder="3-15" min="3" max="15"></div>';
      h += '</div>';

      h += '<button class="btn" style="width:100%;margin-top:8px;padding:10px;font-size:12px" onclick="NABZ.erfUI._suggestESI()">🤖 پیشنهاد ESI</button>';
      h += '<div id="erfSuggest" style="margin-top:8px"></div>';

      h += '<button class="btn btn-primary btn-block" style="padding:14px;margin-top:12px;font-weight:900" onclick="NABZ.erfUI._submitVisit()">✅ ثبت پذیرش</button>';

      E._openSheet(h);
    },

    async _suggestESI() {
      const body = {
        vitals: {
          hr: parseFloat(document.getElementById('erfHR').value) || null,
          bp_sys: parseFloat(document.getElementById('erfSBP').value) || null,
          rr: parseFloat(document.getElementById('erfRR').value) || null,
          temp: parseFloat(document.getElementById('erfTemp').value) || null,
          spo2: parseFloat(document.getElementById('erfSpO2').value) || null,
          gcs: parseFloat(document.getElementById('erfGCS').value) || 15
        }
      };
      try {
        const r = await E._api('/api/erf/suggest-esi', { method: 'POST', body: JSON.stringify(body) });
        const el = document.getElementById('erfSuggest');
        if (!el) return;
        const esi = ESI[r.suggestedESI - 1] || ESI[2];
        let h = '<div class="card" style="border-color:var(--' + esi.color + ');padding:10px">';
        h += '<div style="font-weight:900;color:var(--' + esi.color + ')">ESI ' + r.suggestedESI + ' — ' + esi.label + '</div>';
        if (r.reasons && r.reasons.length) {
          h += '<div style="font-size:11px;color:var(--fg-2);margin-top:4px">' + E._esc(r.reasons.join(' · ')) + '</div>';
        }
        h += '</div>';
        el.innerHTML = h;
        window._erfSuggestedESI = r.suggestedESI;
      } catch (e) {
        document.getElementById('erfSuggest').innerHTML = '<div class="hint warn">پیشنهاد ممکن نشد</div>';
      }
    },

    async _submitVisit() {
      const name = document.getElementById('erfName').value.trim();
      const cc = document.getElementById('erfCC').value.trim();
      if (!name || !cc) return alert('نام و شکایت اصلی الزامی');
      const body = {
        patientName: name,
        age: parseInt(document.getElementById('erfAge').value) || null,
        sex: document.getElementById('erfSex').value,
        nationalId: document.getElementById('erfNID').value,
        chiefComplaint: cc,
        arrivalMode: document.getElementById('erfArrival').value,
        vitals: {
          hr: parseFloat(document.getElementById('erfHR').value) || null,
          bp_sys: parseFloat(document.getElementById('erfSBP').value) || null,
          rr: parseFloat(document.getElementById('erfRR').value) || null,
          temp: parseFloat(document.getElementById('erfTemp').value) || null,
          spo2: parseFloat(document.getElementById('erfSpO2').value) || null,
          gcs: parseFloat(document.getElementById('erfGCS').value) || 15
        }
      };
      try {
        const r = await E._api('/api/erf/visit', { method: 'POST', body: JSON.stringify(body) });
        E._closeAll();
        NABZ._toast('✅ پذیرش ثبت شد');
        // Auto-open triage
        setTimeout(() => E.triageVisit(r.id), 300);
      } catch (e) { alert('خطا: ' + e.message); }
    },

    // ═══════════════════════════════════════════════════
    //  TRIAGE
    // ═══════════════════════════════════════════════════
    async triageVisit(visitId) {
      let h = '<div class="bs-handle"></div>';
      h += '<div class="bs-hd"><div class="bs-title">🚑 تریاژ ESI</div>';
      h += '<button class="bs-close" onclick="this.closest(\'.bs-backdrop\').remove()">✕</button></div>';

      if (window._erfSuggestedESI) {
        h += '<div class="hint info" style="margin-bottom:12px">🤖 پیشنهاد سیستم: ESI ' + window._erfSuggestedESI + '</div>';
      }

      ESI.forEach(e => {
        const maxWait = e.maxWaitMin > 0 ? 'حداکثر ' + e.maxWaitMin + ' دقیقه' : 'فوری';
        h += '<button onclick="NABZ.erfUI._submitTriage(\'' + visitId + '\',' + e.level + ')" ';
        h += 'style="width:100%;padding:12px;margin-bottom:6px;background:var(--bg-2);border:2px solid var(--' + e.color + ');border-radius:10px;font-family:inherit;color:var(--fg);text-align:right;cursor:pointer;display:flex;gap:10px;align-items:center">';
        h += '<div style="width:36px;height:36px;background:var(--' + e.color + ');color:#fff;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:900;flex-shrink:0">' + e.level + '</div>';
        h += '<div style="flex:1"><div style="font-weight:900;font-size:13px">' + e.label + '</div>';
        h += '<div style="font-size:10.5px;color:var(--fg-2);margin-top:2px">' + e.examples + '</div>';
        h += '<div style="font-size:10px;color:var(--' + e.color + ');margin-top:2px;font-weight:800">' + maxWait + '</div></div>';
        h += '</button>';
      });

      E._openSheet(h);
    },

    async _submitTriage(visitId, level) {
      try {
        await E._api('/api/erf/visit/' + visitId + '/triage', {
          method: 'POST', body: JSON.stringify({ esiLevel: level })
        });
        E._closeAll();
        NABZ._toast('✅ تریاژ ESI ' + level);
        // Refresh dashboard
        if (NABZ.state.current === 'emergency_full.er_dashboard' || !NABZ.state.current) {
          E.dashboard();
        }
      } catch (e) { alert('خطا: ' + e.message); }
    },

    // ═══════════════════════════════════════════════════
    //  DISPOSITION
    // ═══════════════════════════════════════════════════
    _openDispositionModal(visitId) {
      let h = '<div class="bs-handle"></div>';
      h += '<div class="bs-hd"><div class="bs-title">📋 تصمیم نهایی</div>';
      h += '<button class="bs-close" onclick="this.closest(\'.bs-backdrop\').remove()">✕</button></div>';
      const actions = [
        { code: 'admit', icon: '🏥', label: 'بستری', cls: 'primary' },
        { code: 'discharge', icon: '🚪', label: 'ترخیص', cls: 'ok' },
        { code: 'transfer', icon: '🔄', label: 'انتقال', cls: '' },
        { code: 'death', icon: '💀', label: 'فوت', cls: 'dng' },
        { code: 'elope', icon: '🏃', label: 'فرار بیمار', cls: '' }
      ];
      actions.forEach(a => {
        h += '<button class="btn ' + (a.cls ? 'btn-' + a.cls : '') + '" style="width:100%;padding:12px;margin-bottom:6px;display:flex;align-items:center;gap:10px;font-weight:900" onclick="NABZ.erfUI._doDisposition(\'' + visitId + '\',\'' + a.code + '\')">';
        h += '<span style="font-size:20px">' + a.icon + '</span><span>' + a.label + '</span></button>';
      });
      E._openSheet(h);
    },

    async _doDisposition(visitId, action) {
      const labels = { admit: 'بستری', discharge: 'ترخیص', transfer: 'انتقال', death: 'فوت', elope: 'فرار' };
      const diagnosis = prompt('تشخیص نهایی (اختیاری):') || '';
      const note = prompt('یادداشت (اختیاری):') || '';
      try {
        await E._api('/api/erf/visit/' + visitId + '/' + action, {
          method: 'POST',
          body: JSON.stringify({ finalDiagnosis: diagnosis, note: note })
        });
        E._closeAll();
        NABZ._toast('✅ ' + labels[action] + ' ثبت شد');
        E.dashboard();
      } catch (e) { alert('خطا: ' + e.message); }
    },

    // ═══════════════════════════════════════════════════
    //  PRE-HOSPITAL
    // ═══════════════════════════════════════════════════
    async showPreHospital(p, d) {
      const m = document.getElementById('content');
      if (!d) {
        m.innerHTML = '<div style="text-align:center;padding:40px"><span class="spinner"></span></div>';
        try { d = await E._api('/api/erf/prehospital'); }
        catch (e) { m.innerHTML = '<div class="empty">خطا: ' + E._esc(e.message) + '</div>'; return; }
      }
      const items = d.items || [];
      const incoming = items.filter(x => x.status === 'incoming');
      const arrived = items.filter(x => x.status === 'arrived');

      let h = '<div class="sec-hd"><span>🚑 پیش‌بیمارستانی</span>';
      h += '<span class="rd-mini">' + incoming.length + ' در راه / ' + arrived.length + ' رسید</span></div>';
      h += '<button class="btn btn-primary btn-block" style="padding:12px;margin-bottom:12px" onclick="NABZ.erfUI.newPreHospital()">➕ ثبت مورد جدید</button>';

      if (!items.length) {
        h += '<div class="empty">موردی ثبت نشده</div>';
      } else {
        if (incoming.length) {
          h += '<div style="font-size:12px;font-weight:900;color:var(--dng);margin:12px 0 8px;padding-bottom:6px;border-bottom:2px solid var(--dng)">🚑 در راه (' + incoming.length + ')</div>';
          incoming.forEach(x => { h += E._preHospitalRow(x); });
        }
        if (arrived.length) {
          h += '<div style="font-size:12px;font-weight:900;color:var(--ok);margin:12px 0 8px;padding-bottom:6px;border-bottom:2px solid var(--ok)">✅ رسیده (' + arrived.length + ')</div>';
          arrived.slice(0, 10).forEach(x => { h += E._preHospitalRow(x); });
        }
      }
      m.innerHTML = h;
      E._startTimers();
    },

    _preHospitalRow(x) {
      const eta = x.etaMinutes > 0 ? new Date(new Date(x.createdAt).getTime() + x.etaMinutes * 60000).toISOString() : null;
      let h = '<div class="row ' + (x.status === 'incoming' ? 'hi' : 'lo') + '" onclick="NABZ.erfUI._viewPreHospital(\'' + x.id + '\')">';
      h += '<div class="row-hd"><div class="row-title">🚑 ' + E._esc(x.patientName) + '</div>';
      if (x.status === 'incoming' && eta) {
        h += '<span class="pill dng">ETA <span data-countdown-to="' + eta + '">' + (x.etaMinutes || 0) + 'm</span></span>';
      } else {
        h += '<span class="pill ok">رسید</span>';
      }
      h += '</div>';
      if (x.age) h += '<div class="row-meta">' + x.age + ' سال · ' + (x.sex === 'female' ? 'زن' : 'مرد') + '</div>';
      h += '<div class="row-meta">' + E._esc(x.chiefComplaint || '—') + '</div>';
      if (x.ambulanceCode) h += '<div class="row-meta" style="font-size:10.5px">آمبولانس: ' + E._esc(x.ambulanceCode) + ' · ' + E._esc(x.paramedicName || '') + '</div>';
      h += '</div>';
      return h;
    },

    newPreHospital() {
      let h = '<div class="bs-handle"></div>';
      h += '<div class="bs-hd"><div class="bs-title">🚑 پیش‌بیمارستانی جدید</div>';
      h += '<button class="bs-close" onclick="this.closest(\'.bs-backdrop\').remove()">✕</button></div>';
      h += '<div class="wf-field"><label>نام بیمار *</label><input id="phName" placeholder="نام"></div>';
      h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">';
      h += '<div class="wf-field" style="margin:0"><label>سن</label><input type="number" id="phAge"></div>';
      h += '<div class="wf-field" style="margin:0"><label>جنسیت</label><select id="phSex"><option value="male">مرد</option><option value="female">زن</option></select></div>';
      h += '</div>';
      h += '<div class="wf-field"><label>شکایت اصلی *</label><textarea id="phCC" rows="2"></textarea></div>';
      h += '<div class="wf-field"><label>کد آمبولانس</label><input id="phAmb" placeholder="مثلاً ۱۱۵-۱۲۳۴"></div>';
      h += '<div class="wf-field"><label>نام تکنسین</label><input id="phParamedic"></div>';
      h += '<div class="wf-field"><label>ETA (دقیقه)</label><input type="number" id="phETA" value="10" min="0" max="180"></div>';
      h += '<button class="btn btn-primary btn-block" style="padding:14px;margin-top:12px" onclick="NABZ.erfUI._submitPreHospital()">✅ ثبت</button>';
      E._openSheet(h);
    },

    async _submitPreHospital() {
      const name = document.getElementById('phName').value.trim();
      const cc = document.getElementById('phCC').value.trim();
      if (!name || !cc) return alert('نام و شکایت الزامی');
      try {
        await E._api('/api/erf/prehospital', {
          method: 'POST',
          body: JSON.stringify({
            patientName: name,
            age: parseInt(document.getElementById('phAge').value) || null,
            sex: document.getElementById('phSex').value,
            chiefComplaint: cc,
            ambulanceCode: document.getElementById('phAmb').value,
            paramedicName: document.getElementById('phParamedic').value,
            etaMinutes: parseInt(document.getElementById('phETA').value) || 10,
            arrivalMode: 'ambulance'
          })
        });
        E._closeAll();
        NABZ._toast('✅ ثبت شد');
        if (NABZ.state.current === 'emergency_full.er_prehospital') {
          E.showPreHospital(null, null);
        } else {
          E.dashboard();
        }
      } catch (e) { alert('خطا: ' + e.message); }
    },

    async _viewPreHospital(id) {
      try {
        const d = await E._api('/api/erf/prehospital');
        const x = (d.items || []).find(i => i.id === id);
        if (!x) return alert('یافت نشد');
        let h = '<div class="bs-handle"></div>';
        h += '<div class="bs-hd"><div class="bs-title">🚑 ' + E._esc(x.patientName) + '</div>';
        h += '<button class="bs-close" onclick="this.closest(\'.bs-backdrop\').remove()">✕</button></div>';
        h += '<div class="card" style="margin-bottom:12px">';
        if (x.age) h += '<div style="font-size:12px">سن: ' + x.age + ' · ' + (x.sex === 'female' ? 'زن' : 'مرد') + '</div>';
        h += '<div style="font-size:12px">شکایت: ' + E._esc(x.chiefComplaint || '—') + '</div>';
        if (x.ambulanceCode) h += '<div style="font-size:12px">آمبولانس: ' + E._esc(x.ambulanceCode) + '</div>';
        if (x.paramedicName) h += '<div style="font-size:12px">تکنسین: ' + E._esc(x.paramedicName) + '</div>';
        if (x.status === 'incoming' && x.etaMinutes) {
          const eta = new Date(new Date(x.createdAt).getTime() + x.etaMinutes * 60000).toISOString();
          h += '<div style="font-size:12px">ETA: <b><span data-countdown-to="' + eta + '">' + x.etaMinutes + 'm</span></b></div>';
        }
        h += '</div>';
        if (x.status === 'incoming') {
          h += '<button class="btn btn-primary btn-block" style="padding:14px;margin-bottom:20px;font-weight:900" onclick="NABZ.erfUI._convertPreHospital(\'' + x.id + '\')">🚨 تبدیل به پذیرش اورژانس</button>';
        }
        E._openSheet(h);
        E._startTimers();
      } catch (e) { alert('خطا: ' + e.message); }
    },

    async _convertPreHospital(id) {
      try {
        await E._api('/api/erf/prehospital/' + id + '/convert', { method: 'POST', body: '{}' });
        E._closeAll();
        NABZ._toast('✅ تبدیل شد');
        if (NABZ.state.current === 'emergency_full.er_prehospital') {
          E.showPreHospital(null, null);
        } else {
          E.dashboard();
        }
      } catch (e) { alert('خطا: ' + e.message); }
    },

    // ═══════════════════════════════════════════════════
    //  REFERRALS
    // ═══════════════════════════════════════════════════
    async showReferrals(p, d) {
      const m = document.getElementById('content');
      if (!d) {
        m.innerHTML = '<div style="text-align:center;padding:40px"><span class="spinner"></span></div>';
        try { d = await E._api('/api/erf/referral'); }
        catch (e) { m.innerHTML = '<div class="empty">خطا: ' + E._esc(e.message) + '</div>'; return; }
      }
      const items = d.items || [];
      const inc = items.filter(x => x.direction === 'incoming');
      const out = items.filter(x => x.direction === 'outgoing');

      let h = '<div class="sec-hd"><span>↪️ ارجاع و اعزام</span></div>';
      h += '<button class="btn btn-primary btn-block" style="padding:12px;margin-bottom:12px" onclick="NABZ.erfUI.newReferral()">➕ ثبت ارجاع</button>';
      h += '<div class="rd-stats" style="grid-template-columns:1fr 1fr;margin-bottom:14px">';
      h += '<div class="rd-stat info"><div class="v">' + inc.length + '</div><div class="l">ورودی</div></div>';
      h += '<div class="rd-stat warn"><div class="v">' + out.length + '</div><div class="l">خروجی</div></div>';
      h += '</div>';

      if (inc.length) {
        h += '<div style="font-size:12px;font-weight:900;color:var(--primary);margin:12px 0 8px;padding-bottom:6px;border-bottom:2px solid var(--primary)">📥 ورودی</div>';
        inc.forEach(x => { h += E._referralRow(x); });
      }
      if (out.length) {
        h += '<div style="font-size:12px;font-weight:900;color:var(--warn);margin:12px 0 8px;padding-bottom:6px;border-bottom:2px solid var(--warn)">📤 خروجی</div>';
        out.forEach(x => { h += E._referralRow(x); });
      }
      if (!items.length) h += '<div class="empty">ارجاعی ثبت نشده</div>';
      m.innerHTML = h;
    },

    _referralRow(x) {
      const SC = { pending_arrival:'warn', pending_send:'info', arrived:'ok', sent:'ok', cancelled:'dng' };
      const SF = { pending_arrival:'در انتظار ورود', pending_send:'در انتظار ارسال', arrived:'رسید', sent:'ارسال شد', cancelled:'لغو' };
      let h = '<div class="row ' + (x.priority === 'emergency' ? 'hi' : 'lo') + '" onclick="NABZ.erfUI._viewReferral(\'' + x.id + '\')">';
      h += '<div class="row-hd"><div class="row-title">' + E._esc(x.patientName) + '</div>';
      h += '<span class="pill ' + (SC[x.status] || 'info') + '">' + (SF[x.status] || x.status) + '</span></div>';
      if (x.fromHospital) h += '<div class="row-meta">از: ' + E._esc(x.fromHospital) + '</div>';
      if (x.toHospital) h += '<div class="row-meta">به: ' + E._esc(x.toHospital) + '</div>';
      if (x.reason) h += '<div class="row-meta" style="font-size:11px">' + E._esc(x.reason) + '</div>';
      h += '</div>';
      return h;
    },

    newReferral() {
      let h = '<div class="bs-handle"></div>';
      h += '<div class="bs-hd"><div class="bs-title">↪️ ارجاع جدید</div>';
      h += '<button class="bs-close" onclick="this.closest(\'.bs-backdrop\').remove()">✕</button></div>';
      h += '<div class="wf-field"><label>جهت</label><select id="refDir"><option value="incoming">ورودی (از مرکز دیگر)</option><option value="outgoing">خروجی (به مرکز دیگر)</option></select></div>';
      h += '<div class="wf-field"><label>نام بیمار *</label><input id="refName"></div>';
      h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">';
      h += '<div class="wf-field" style="margin:0"><label>سن</label><input type="number" id="refAge"></div>';
      h += '<div class="wf-field" style="margin:0"><label>جنسیت</label><select id="refSex"><option value="male">مرد</option><option value="female">زن</option></select></div>';
      h += '</div>';
      h += '<div class="wf-field"><label>از بیمارستان</label><input id="refFrom"></div>';
      h += '<div class="wf-field"><label>به بیمارستان</label><input id="refTo"></div>';
      h += '<div class="wf-field"><label>دلیل *</label><textarea id="refReason" rows="2"></textarea></div>';
      h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">';
      h += '<div class="wf-field"><label>اولویت</label><select id="refPriority"><option value="routine">روتین</option><option value="urgent">فوری</option><option value="emergency">اورژانسی</option></select></div>';
      h += '<div class="wf-field"><label>حمل</label><select id="refTransport"><option value="ground_ambulance">آمبولانس زمینی</option><option value="air_ambulance">آمبولانس هوایی</option><option value="private">شخصی</option><option value="family">خانواده</option></select></div>';
      h += '</div>';
      h += '<button class="btn btn-primary btn-block" style="padding:14px;margin-top:12px" onclick="NABZ.erfUI._submitReferral()">✅ ثبت</button>';
      E._openSheet(h);
    },

    async _submitReferral() {
      const name = document.getElementById('refName').value.trim();
      const reason = document.getElementById('refReason').value.trim();
      if (!name || !reason) return alert('نام و دلیل الزامی');
      try {
        await E._api('/api/erf/referral', {
          method: 'POST',
          body: JSON.stringify({
            direction: document.getElementById('refDir').value,
            patientName: name,
            age: parseInt(document.getElementById('refAge').value) || null,
            sex: document.getElementById('refSex').value,
            fromHospital: document.getElementById('refFrom').value,
            toHospital: document.getElementById('refTo').value,
            reason: reason,
            priority: document.getElementById('refPriority').value,
            transport: document.getElementById('refTransport').value
          })
        });
        E._closeAll();
        NABZ._toast('✅ ثبت شد');
        if (NABZ.state.current === 'emergency_full.er_referrals') {
          E.showReferrals(null, null);
        } else {
          E.dashboard();
        }
      } catch (e) { alert('خطا: ' + e.message); }
    },

    async _viewReferral(id) {
      try {
        const d = await E._api('/api/erf/referral');
        const x = (d.items || []).find(i => i.id === id);
        if (!x) return alert('یافت نشد');
        let h = '<div class="bs-handle"></div>';
        h += '<div class="bs-hd"><div class="bs-title">↪️ ' + E._esc(x.patientName) + '</div>';
        h += '<button class="bs-close" onclick="this.closest(\'.bs-backdrop\').remove()">✕</button></div>';
        h += '<div class="card" style="margin-bottom:12px">';
        h += '<div style="font-size:12px">جهت: <b>' + (x.direction === 'incoming' ? 'ورودی' : 'خروجی') + '</b></div>';
        if (x.fromHospital) h += '<div style="font-size:12px">از: ' + E._esc(x.fromHospital) + '</div>';
        if (x.toHospital) h += '<div style="font-size:12px">به: ' + E._esc(x.toHospital) + '</div>';
        h += '<div style="font-size:12px">اولویت: ' + E._esc(x.priority) + '</div>';
        if (x.reason) h += '<div style="font-size:12px;margin-top:6px"><b>دلیل:</b> ' + E._esc(x.reason) + '</div>';
        h += '</div>';
        if (x.status === 'pending_arrival' || x.status === 'pending_send') {
          h += '<div style="display:flex;gap:6px;margin-bottom:20px">';
          h += '<button class="btn btn-ok" style="flex:1;padding:12px;font-weight:900" onclick="NABZ.erfUI._updateReferralStatus(\'' + x.id + '\',\'' + (x.direction === 'incoming' ? 'arrived' : 'sent') + '\')">✅ تأیید</button>';
          h += '<button class="btn btn-dng" style="flex:1;padding:12px" onclick="NABZ.erfUI._updateReferralStatus(\'' + x.id + '\',\'cancelled\')">❌ لغو</button>';
          h += '</div>';
        }
        E._openSheet(h);
      } catch (e) { alert('خطا: ' + e.message); }
    },

    async _updateReferralStatus(id, status) {
      try {
        await E._api('/api/erf/referral/' + id, { method: 'PUT', body: JSON.stringify({ status }) });
        E._closeAll();
        NABZ._toast('✅ به‌روز شد');
        if (NABZ.state.current === 'emergency_full.er_referrals') E.showReferrals(null, null);
        else E.dashboard();
      } catch (e) { alert('خطا: ' + e.message); }
    },

    // ═══════════════════════════════════════════════════
    //  LIVE SUBSCRIPTION
    // ═══════════════════════════════════════════════════
    _liveSubscribed: false,
    _subscribeLive() {
      if (E._liveSubscribed) return;
      if (!window.Live || typeof Live.on !== 'function') return;
      const events = ['er.visit.registered','er.visit.triaged','er.visit.zoned','er.visit.disposition','er.prehospital.handoff','er.visit.from_prehospital','er.referral.created','ed.visit.created','ed.triage.completed'];
      events.forEach(evt => {
        Live.on(evt, () => {
          if (NABZ.state.current === 'emergency_full.er_dashboard') {
            E.dashboard();
          }
        });
      });
      E._liveSubscribed = true;
    }
  };

  // ═══ Bootstrap ═══
  var waitCount = 0;
  function ready(fn) {
    if (window.NABZ && typeof NABZ.show === 'function') return fn();
    if (++waitCount >= 60) return console.warn('[erf-ui] timeout');
    setTimeout(() => ready(fn), 100);
  }

  ready(function() {
    NABZ.erfUI = E;

    // Register with dispatcher
    if (typeof NABZ.registerKind === 'function') {
      NABZ.registerKind('erf_dashboard', function(p, d) { return E.dashboard(p, d); });
      NABZ.registerKind('erf_prehospital', function(p, d) { return E.showPreHospital(p, d); });
      NABZ.registerKind('erf_referrals', function(p, d) { return E.showReferrals(p, d); });
    }

    // Also override NABZ.showItem for any visit detail
    var prevShowItem = NABZ.showItem;
    if (typeof prevShowItem === 'function') {
      NABZ.showItem = function(pid, iid) {
        if (pid === 'emergency.ed') {
          if (typeof NABZ.em !== 'undefined' && NABZ.em.viewED) return NABZ.em.viewED(iid);
        }
        return prevShowItem.apply(NABZ, arguments);
      };
    }

    console.log('[erf-ui] loaded ✓ — 6 zones, NEDOCS, ESI triage, prehospital, referrals');
  });
})();
